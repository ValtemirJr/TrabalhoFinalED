typedef struct _empresa {
    char nomeEmpresa[50];
    int cnpj;
}Empresa;